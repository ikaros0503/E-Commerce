<?php
$db_servername = "localhost";
$db_name = "assignment_ado";
$db_user = "root";
$db_password = "";
?>