<?php
	//Start session
	session_start();
	//Check whether the session variable SESS_MEMBER_ID is present or not
	if(isset($_SESSION['SESS_MEMBER_ID']) && !empty(trim($_SESSION['SESS_MEMBER_ID']))) {
			echo $_SESSION['SESS_MEMBER_ID'].'|'.$_SESSION['SESS_USER_NAME'];
	} else {
		echo "NO_SESSION";
	}
?>